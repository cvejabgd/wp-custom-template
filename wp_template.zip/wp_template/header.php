<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php bloginfo('name'); ?></title>
<!--    <link href="--><?php //echo get_stylesheet_uri(); ?><!--" rel="stylesheet">-->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url');
    echo '?' . filemtime(get_stylesheet_directory() . '/style.css'); ?>" type="text/css" media="screen"/>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="navbar navbar-default navbar-static-top">
    <div class="container">


        <div class="collapse navbar-collapse navHeaderCollapse">
            <!-- dynamic menu -->
            <?php
            wp_nav_menu(array(
                    'menu' => 'primary',
                    'theme_location' => 'primary',
                    'depth' => 2,

                    /*'container'         => 'div',
                    'container_class'   => 'collapse navbar-collapse',
                    'container_id'      => 'bs-example-navbar-collapse-1',*/

                    'menu_class' => 'nav navbar-nav navbar-right',
                    'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                    'walker' => new wp_bootstrap_navwalker())
            );
            ?>

        </div>

    </div>
</div>
		
