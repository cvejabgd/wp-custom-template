<?php get_header(); ?>

	<!-- hero naslov poslednjeg posta, ogranicen na 1 -->
	<?php
		query_posts('posts_per_page=1');
			while(have_posts()) : the_post(); ?>

		<div class="fullWidth">
			<div class="jumbotron">
				<div class="container">
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p><?php the_excerpt(); ?></p>
				</div>
			</div>
		</div>

	<?php endwhile; wp_reset_query(); ?>
	<!-- panel side -->
	<div class="panel panel-default panel-body">
		<div class="container">
			<div class="row">
				<div class="col-md-2">
					<ul class="nav nav-pills nav-stacked">
						<?php wp_list_categories('orderby=name&title_li'); ?>
					</ul>
				</div>
				<div class="col-md-10">
					<!-- vadi postove i prekida loop-->
					<?php while(have_posts()) : the_post(); ?>

						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p><?php the_excerpt(); ?></p>
						<p class="text-muted">Posted by <?php the_author(); ?> on <?php the_time('j. n. Y'); ?></p>

					<?php endwhile; wp_reset_query(); ?>
				</div>
			</div>
		</div>
	</div>

<?php get_footer(); ?>