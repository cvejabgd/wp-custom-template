<?php 

	// Register Custom Navigation Walker
	require_once('wp_bootstrap_navwalker.php');


	register_nav_menus( array(
    	'primary' => __( 'Primary Menu', 'krojac' ),
	) );
	
	
	
	// Remove WordPress' wp_head() generated links
	remove_action('wp_head', 'rel_canonical'); // Remove WordPress' canonical links
	remove_action( 'wp_head', 'feed_links_extra', 3 ); // Removes the links to the extra feeds such as category feeds
	remove_action( 'wp_head', 'feed_links', 2 ); // Removes links to the general feeds: Post and Comment Feed
	remove_action( 'wp_head', 'rsd_link'); // Removes the link to the Really Simple Discovery service endpoint, EditURI link
	remove_action( 'wp_head', 'wlwmanifest_link'); // Removes the link to the Windows Live Writer manifest file.
	remove_action( 'wp_head', 'index_rel_link'); // Removes the index link
	remove_action( 'wp_head', 'parent_post_rel_link'); // Removes the prev link
	remove_action( 'wp_head', 'start_post_rel_link'); // Removes the start link
	remove_action( 'wp_head', 'adjacent_posts_rel_link'); // Removes the relational links for the posts adjacent to the current post.
	remove_action( 'wp_head', 'wp_generator'); // Removes the WordPress version i.e. -
	
	
	/**
	 * Filters wp_title to print a neat <title> tag based on what is being viewed.
	 * Modifikacija Title-a strane
	 *
	 * @param string $title Default title text for current view.
	 * @param string $sep Optional separator.
	 * @return string The filtered title.
	 */
	function theme_name_wp_title( $title, $sep ) {
		if ( is_feed() ) {
			return $title;
		}
		
		global $page, $paged;

		// Add the blog name
		$title .= get_bloginfo( 'name', 'display' );

		// Add the blog description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		//if ( $site_description && ( is_home() || is_front_page() ) ) {
		if ( $site_description && ( is_front_page() ) ) {
			$title .= " $sep $site_description";
		}

		// Add a page number if necessary:
		if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
			$title .= " $sep " . sprintf( __( 'Strana %s', '_s' ), max( $paged, $page ) );
		}

		return $title;
	}
	add_filter( 'wp_title', 'theme_name_wp_title', 10, 2 );
