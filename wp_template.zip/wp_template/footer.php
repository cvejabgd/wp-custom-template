		<footer class = "navbar navbar-default">

			<div class = "container">

			</div>

		</footer>


		<?php wp_footer(); ?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src = "<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>

	</body>
</html>
